package com.uereka.uereka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UerekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
